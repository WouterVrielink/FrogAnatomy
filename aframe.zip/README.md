# BasEnWouterOpAvontuur

In this project we explored a multitude of ways to study the anatomy of a frog. Specifically in a virtual setting, making real hands-on frog practicals obsolete.

The aframe.html folder holds the website. Run a webserver with the provided 'server.bat'.

Authors:
Bas Châtel (10246215)
Wouter Vrielink (10433597)
